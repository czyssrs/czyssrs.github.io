#
#11/19/2014 2:45:10 PM
#Author: Honglei Liu <liuhonglei@gmail.com>
#
#Description: randomly sample sequences from large files
#

import sys
import os
import os.path
import random

def readseqs(file_name):
	names=[]
	seqs=[]
	with open(file_name) as f:
		for line in f:
			if line.startswith('>'):
				names.append(line.strip())
			else:
				seqs.append(line.strip())
	return (names,seqs)

if __name__ == '__main__':
	''' 
	[1] number of sampled sequences (if the total number of sequences is smaller than this number, return all the sequences)
	[2] number of samples (if total number < max_num, then just 1 sample)
	[3]	input directory
	[4] output direcotry
	'''

	max_num=int(sys.argv[1])
	sample_num=int(sys.argv[2])
	in_dir=sys.argv[3]
	out_dir=sys.argv[4]

	try:
		if not os.path.isdir(in_dir):
			print "input direcotry doesn't exist!"
			sys.exit(1);

		if not os.path.isdir(out_dir):
			print "creating "+out_dir
			os.makedirs(out_dir)

		for file_name in os.listdir(in_dir):
			vect=readseqs(os.path.join(in_dir,file_name))
			names=vect[0]
			seqs=vect[1]
			if len(seqs)<=max_num:
				out_file=os.path.join(out_dir,file_name+"_0")
				with open(out_file,'w') as f:
					for t in range(len(seqs)):
						f.write(names[t]+"\n")
						f.write(seqs[t]+"\n")
			else:
				for i in range(sample_num):
					out_file=os.path.join(out_dir,file_name+"_"+str(i))
					with open(out_file,'w') as f:
						pos=random.randint(0,len(seqs)-max_num-1)
						t_name=names[pos:pos+max_num+1]
						t_seq=seqs[pos:pos+max_num+1]
						for t in range(len(t_seq)):
							f.write(t_name[t]+"\n")
							f.write(t_seq[t]+"\n")
	except Exception, e:
		print e
	


