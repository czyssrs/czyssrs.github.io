#
# 11/20/2014 5:27:26 PM
# Author: Honglei Liu <liuhonglei@gmail.com>
#
# Description: pipeline of ABP+MEME
#

import sys
import os
import argparse
import subprocess
import shutil

proteinAlphabet='ACDEFGHIKLMNPQRSTVWY'
dnaAlphabet='AGCT'



class ARGS(object):
	pass

def parseConfig():
	'''
	read and parse the config file
	'''
	configArgs=['input']
	if not os.path.exists('settings.txt'):
		print 'can not find settings.txt. continue...'
	else:
		#print 'reading config file...'
		with open('settings.txt') as f:
			for line in f:
				if line.startswith('#'):
					continue
				else:
					line=line.strip()
					configArgs+=line.split()
	return configArgs


def setParser(parser):
	'''
	set up the parser
	'''
	parser.add_argument('dataset', metavar='<dataset>',help='file containing sequences in FASTA format')
	parser.add_argument('-v','--verbose',dest='verbose',action="store_true", default=False,help='verbose mode')

	## common options
	group=parser.add_argument_group('common options')
	group.add_argument('-o',dest='output_dir',metavar='<output dir>',default='ouput',help='name of directory for output files will replace existing directory')
	group.add_argument('-text',dest='text',action="store_true", default=False,help='output in text format without generating pwm logos')
	group.add_argument('-dna',dest='dna',action="store_true", default=False,help='sequences use DNA alphabet (default is protein alphabet)')
	group.add_argument('-evt',dest='evt',metavar='<ev>',type=float, default=0.01,help='the threshold of E-value for a motif to be significant (default: 0.01)')
	group.add_argument('-minsites',dest='minsites',metavar='<minsites>',type=int, default=10,help='minimum number of sites for each motif (default: 10)')
	group.add_argument('-minw',dest='minw',metavar='<minw>',type=int, default=6,help='minumum motif width (default: 6)')
	group.add_argument('-maxw',dest='maxw',metavar='<maxw>',type=int, help='maximum motif width (default is equal to seql)')
	group.add_argument('-bfile ',dest='bfile',metavar='<bfile>',default='.bfile',help='name of background Markov model file')
	
	
	## asc specific options
	group=parser.add_argument_group('asc related options')
	group.add_argument('-npar',dest='npar',metavar='<npar>',type=int, help='number of partitions (if not specified, the algorithm will run recursively until it reaches termination condition)')
	group.add_argument('-seql',dest='seql',metavar='<seql>',type=int,help='length of sequences (if not specified, the algorithm will set seql equal to the average length of all sequences)')
	group.add_argument('-d',dest='d',metavar='<d>',type=int, default=5,help='# of anchors in each partition center (default: 5)')
	group.add_argument('-maxi',dest='maxi',metavar='maxi',type=int, default=1000,help='maximum # of iterations (default: 1000)')
	group.add_argument('-ct',dest='ct',metavar='<ct>',type=float, default=0.01,help='threshold of convergence criteria (default: 0.01)')
	group.add_argument('-mt',dest='mt',metavar='<mt>',type=int, default=1,help='the threshold of the number of common anchors to combine two partitions (default: 1)')
	group.add_argument('-cs',dest='cs',metavar='<cs>',type=float, default=0.0,help='the convergence threshold will be added with this step after each iteration (default: 0.00)')
	group.add_argument('-pa',dest='pa',metavar='<pa>',type=int, default=50,help='penalty number for small partitions (default: 50)')
	
	## postprocessing options
	group=parser.add_argument_group('postprocessing options')
	group.add_argument('-nsample',dest='nsample',metavar='<nsample>',type=int, default=2,help='the number of samples for each partition (default: 2)')
	group.add_argument('-nseq',dest='nseq',metavar='<nseq>',type=int, default=500,help='the number of sequences per sample (default: 500)')
	group.add_argument('-nsmotif',dest='nsmotif',metavar='<nsmotif>',type=int, default=3,help='number of motifs to be discovered per sample (default: 3)')
	group.add_argument('-occ',dest='occ',action="store_true", default=False,help='find occurrences for each motif')
	group.add_argument('-re',dest='re',action="store_true", default=False,help='re-calculate E-value for each motif')
	group.add_argument('-klt',dest='kl_thres',metavar='<klt>',type=float, default=1.5,help='the threshold of KL value to merge two motifs (default: 1.5)')
	group.add_argument('-njobs',dest='njobs',metavar='<njobs>',type=int, default=25,help='number of MEME jobs that are run simultaneously (default: 25)')
	
	
def genBackground(args):
	'''
	generate background model
	'''
	tDir=args.output_dir
	if os.path.isdir(tDir):
		shutil.rmtree(tDir)
	print "creating "+tDir
	os.makedirs(tDir)
	print "scaning "+args.dataset

	if not args.dna:
		alpha=proteinAlphabet
	else:
		alpha=dnaAlphabet
	freqs={}
	for c in alpha:
		freqs[c]=0
	totalchars=0
	minL=sys.maxint
	avgL=0.0
	totallines=0
	with open(args.dataset) as f:
		for line in f:
			if not line.startswith('>'):
				if minL>len(line.strip()):
					minL=len(line.strip())
				avgL+=len(line.strip())
				totallines+=1
				for c in line.strip():
					if c in freqs:
						freqs[c]+=1
						totalchars+=1
					else:
						print "illegal characters in line "+str(2*totallines)
						sys.exit(-1)
	backmodel=[float(freqs[c])/totalchars for c in alpha]
	avgL=int(avgL/totallines)

	print 'writing pwm file header'
	pwm_file=os.path.join(args.output_dir,'pwms.txt')
	with open(pwm_file,'w+') as f:
		f.write('MEME version 4\n\n')
		f.write('ALPHABET= '+alpha+'\n')
		f.write('Background letter frequencies\n')
		for i in range(len(alpha)):
			f.write(alpha[i]+' '+str(backmodel[i])+' ')
		f.write('\n\n')

	print 'writing background model'
	bfile=os.path.join(args.output_dir,'.bfile')
	with open(bfile,'w+') as f:
		for i in range(len(alpha)):
			f.write(alpha[i]+' '+str(backmodel[i])+'\n')

	# get average length of sequences
	if args.seql==None:
		args.seql=avgL
		print 'seql is set to '+str(args.seql)
	if args.maxw==None:
		args.maxw=args.seql
		print 'maxw is set to '+str(args.maxw)

		
def examineFile(args):
	'''
	scan and check file's legality
	'''
	print 'examining '+args.dataset

	datafile=os.path.join(args.output_dir,'.data')
	title=''
	ignored=0
	read=0
	with open(args.dataset) as f:
		with open(datafile,'w+') as fout:
			for line in f:
				if not line.startswith('>'):
					if len(line.strip())<args.seql:
						ignored+=1
						continue
					else:
						fout.write(title)
						fout.write(line)
						read+=1
				else:
					title=line
	if ignored!=0:
		print str(read)+' sequences read'
		print str(ignored)+' sequences ignored due to short length(<seql)'
		args.dataset=datafile
	else:
		print 'OK'



def runMEME(args):
	'''
	run multiple MEME instances for each partition
	'''
	print '---------------------------'
	tDir=os.path.join(args.output_dir,'.meme')
	if os.path.isdir(tDir):
		shutil.rmtree(tDir)
	print "creating "+tDir
	os.makedirs(tDir)

	child=subprocess.Popen(['ls',os.path.join(args.output_dir,'samples')],stdout=subprocess.PIPE)
	(stdoutdata, stderrdata)=child.communicate()

	sample_files=stdoutdata.split()
	start=0
	end=args.njobs
	if end<len(sample_files):
		print "too many samples. MEME will be run sequentially with {0} instances in each group".format(args.njobs)
	else:
		end=len(sample_files)
	while  start<len(sample_files):
		t_files=sample_files[start:end]
		print "running MEME for samples {0}-{1}".format(start+1,end)
		start+=args.njobs
		end+=args.njobs
		if end>len(sample_files):
			end=len(sample_files)


		print 'running MEME with command: '
		childs=[]
		for sfile in t_files:
			if os.path.exists('meme'):
				command=['./meme']
			else:
				command=['meme']
			command+=[os.path.join(args.output_dir,'samples',sfile)]
			command+=['-oc',os.path.join(tDir,sfile)]
			if args.text:
				command+=['-text']
			if not args.dna:
				command+=['-protein']
			else:
				command+=['dna']
			command+=['-nmotifs',str(args.nsmotif)]
			command+=['-evt',str(args.evt)]
			command+=['-minsites',str(args.minsites)]
			command+=['-minw',str(args.minw)]
			command+=['-maxw',str(args.maxw)]
			command+=['-bfile',os.path.join(args.output_dir,args.bfile)]
			if args.verbose:
				command+=['-V']
			f=open(os.path.join(tDir,sfile+'.out'),'w+')
			print ' '.join(command)
			child=subprocess.Popen(command,stdout=f,stderr=f)
			childs.append(child)

		print 'waiting for MEME to finish...'
		isfinish=False
		while not isfinish:
			isfinish=True
			for child in childs:
				returncode=child.poll()
				if returncode is None:
					isfinish=False
					break
				elif returncode<0:
					print 'meme run into error: '+str(-returncode)
					sys.exit(-1)
		print '...done'


def runMerge(args):
	'''
	merge duplicate motifs
	'''
	print '---------------------------'
	pwm_file=os.path.join(args.output_dir,'pwms.txt')
	if not os.path.exists(pwm_file):
		print 'pwm header file does not exist'
		sys.exit(-1)

	child=subprocess.Popen(['find',os.path.join(args.output_dir,'.meme'),'-name','meme.txt'],stdout=subprocess.PIPE)
	(stdoutdata, stderrdata)=child.communicate()
	
	command=['python','merge_motif.py','-merge']
	command+=[pwm_file,str(args.kl_thres),str(args.evt),str(args.minw),str(args.minsites)]
	command+=stdoutdata.split()
	
	print 'merging motifs: '
	print ' '.join(command)
	child=subprocess.Popen(command)
	returncode=child.wait()
	if returncode==None or returncode<0:
		print 'merge_motif.py runs into error'
		sys.exit(-1)

def runLogogen(args):
	'''
	generating logos
	'''
	print '---------------------------'
	tDir=os.path.join(args.output_dir,'logos')
	if os.path.isdir(tDir):
		shutil.rmtree(tDir)
	print "creating "+tDir
	os.makedirs(tDir)	
	#if not args.re:
	pwm_file=os.path.join(args.output_dir,'pwms.txt')
	#else:
	#	pwm_file=os.path.join(args.output_dir,'pwms_with_new_evalue.txt')
	if os.path.exists('meme2images'):
		command=['./meme2images', '-eps']
	else:
		command=['meme2images', '-eps']
	command+=[pwm_file]
	command+=[tDir]
	
	print 'generating logos: '
	print ' '.join(command)
	child=subprocess.Popen(command)
	returncode=child.wait()
	if returncode==None or returncode<0:
		print 'meme2images runs into error'
		sys.exit(-1)


	
def runABP(args):
	'''
	run ABP algorithm once with the number of partitions
	'''
	
	tDir=os.path.join(args.output_dir,'partitions')
	if os.path.isdir(tDir):
		shutil.rmtree(tDir)
	print "creating "+tDir
	os.makedirs(tDir)
	
	command=['./asc',args.dataset,tDir,str(args.npar)]
	command+=['-seql',str(args.seql)]
	command+=['-maxw',str(args.maxw)]
	if args.dna:
		command+=['-alphabet',dnaAlphabet]
	else:
		command+=['-alphabet',proteinAlphabet]
	if args.verbose:
		command+=['-v']
	command+=['-d',str(args.d)]
	command+=['-maxi',str(args.maxi)]
	command+=['-ct',str(args.ct)]
	command+=['-mt',str(args.mt)]
	command+=['-cs',str(args.cs)]
	command+=['-pa',str(args.pa)]

	print '---------------------------'
	print 'running ABP with command: '
	print ' '.join(command)
	child=subprocess.Popen(command)
	returncode=child.wait()
	if returncode==None or returncode<0:
		print 'ABP runs into error'
		sys.exit(-1)

def runABPwithoutParN(args):
	'''
	run ABP recursively without given the number of partitions
	'''
	tDir=os.path.join(args.output_dir,'.partitions')
	if os.path.isdir(tDir):
		shutil.rmtree(tDir)
	print "creating "+tDir
	os.makedirs(tDir)

	tDir=os.path.join(args.output_dir,'partitions')
	if os.path.isdir(tDir):
		shutil.rmtree(tDir)
	print "creating "+tDir
	os.makedirs(tDir)

	runABPRecur(args,args.dataset)

	

def runABPRecur(args,input_file):
	'''
	run ABP recursively
	'''
	if not hasattr(runABPRecur, "in_count"):
		runABPRecur.in_count=1
	if not hasattr(runABPRecur, "out_count"):
		runABPRecur.out_count=1	
		
	data_list=[input_file]
	partitionNums=[2]
	iter_count=0
	trash_pars=[]
	
	while len(data_list) is not 0:
		dataset=data_list.pop()
		partitionN=partitionNums.pop()
		out_dir=os.path.join(args.output_dir,'.partitions',str(runABPRecur.in_count))
		runABPRecur.in_count+=1
		iter_count+=1


		command=['./asc',dataset,out_dir,str(partitionN)]
		command+=['-seql',str(args.seql)]
		command+=['-maxw',str(args.maxw)]
		if args.dna:
			command+=['-alphabet',dnaAlphabet]
		else:
			command+=['-alphabet',proteinAlphabet]
		if args.verbose:
			command+=['-v']
		command+=['-d',str(args.d)]
		command+=['-maxi',str(args.maxi)]
		command+=['-ct',str(args.ct)]
		command+=['-mt',str(args.mt)]
		command+=['-cs',str(args.cs)]
		command+=['-pa',str(args.pa)]

		print '---------------------------'
		print 'running ABP with command: '
		print ' '.join(command)
		child=subprocess.Popen(command)
		returncode=child.wait()
		if returncode==None or returncode<0:
			print 'ABP runs into error'
			sys.exit(-1)
		t=[['0','0']]
		for i in range(1,partitionN+1):
			child=subprocess.Popen(['wc','-l',os.path.join(out_dir,str(i))],stdout=subprocess.PIPE)
			(stdoutdata, stderrdata)=child.communicate()
			t.append(stdoutdata.split())

		t_terminate=False
		for i in range(1,partitionN+1):
			if int(t[i][0])<args.nseq*2:
				#trash_pars.append(os.path.join(out_dir,str(i)))
				t_terminate=True

		# remember the trash partition
		trash_pars.append(os.path.join(out_dir,'0'))
		
		if not t_terminate:
			data_list+=[t[i][1] for i in range(1,partitionN+1)]
			# increase the partition number for every file pushed into the datalist
			partitionNums+=[partitionN+1]*partitionN
		else:
			if iter_count==1 and runABPRecur.out_count!=1: #and int(t1[0])<args.nseq*2 and int(t2[0])<args.nseq*2:
				print 'totally {0} partitions are generated'.format(runABPRecur.out_count)
				return
			for i in range(1,partitionN+1):
				#if not int(t[i][0])<args.nseq*2:
				shutil.copyfile(t[i][1],os.path.join(args.output_dir,'partitions',str(runABPRecur.out_count)))
				print 'finish partition '+str(runABPRecur.out_count)
				runABPRecur.out_count+=1

	print 'copying trash partitions'

	with open(os.path.join(args.output_dir,'partitions','0'),'w+') as dest:
		for file_name in trash_pars:
			with open(file_name) as src:
				shutil.copyfileobj(src, dest)

	runABPRecur(args,os.path.join(args.output_dir,'partitions','0'))



def runSampling(args):
	'''
	run sampling method
	'''
	print '---------------------------'
	parDir=os.path.join(args.output_dir,'partitions')
	tDir=os.path.join(args.output_dir,'samples')
	if os.path.isdir(tDir):
		shutil.rmtree(tDir)
	print "creating "+tDir
	os.makedirs(tDir)

	command=['python','sample_seqs.py']
	command+=[str(args.nseq),str(args.nsample),parDir,tDir]
	
	
	print 'sampling sequences from partition results: '
	print ' '.join(command)
	child=subprocess.Popen(command)
	returncode=child.wait()
	if returncode==None or returncode<0:
		print 'sampling runs into error'
		sys.exit(-1)

def runFimo(args):
	'''
	run fimo to find occurrences of motifs
	'''
	print '---------------------------'
	# tDir=os.path.join(args.output_dir,'fimo')
	# if os.path.isdir(tDir):
	# 	shutil.rmtree(tDir)
	# print "creating "+tDir
	# os.makedirs(tDir)

	pwm_file=os.path.join(args.output_dir,'pwms.txt')
	bfile=os.path.join(args.output_dir,'.bfile')
	fimofile=os.path.join(args.output_dir,'.fimo')

	if os.path.exists('fimo'):
		command=['./fimo']
	else:
		command=['fimo']
	command+=['-text']
	command+=['--bgfile',bfile]

	command+=['--thresh','0.0001']
	command+=[pwm_file]
	command+=[args.dataset]

	
	print 'finding occurrences of motifs with fimo: '
	print ' '.join(command)
	f=open(fimofile,'w+')
	child=subprocess.Popen(command,stdout=f,stderr=None)
	returncode=child.wait()
	if returncode==None or returncode<0:
		print 'fimo runs into error'
		sys.exit(-1)
	
	print 'outputting matched sequences'
	match_file=os.path.join(args.output_dir,'pwm_matched_sequences.txt')
	title=''
	matseqs={}
	maxMotifN=0
	with open(fimofile) as f:
		title=f.readline()
		while True:
			line=f.readline()
			if len(line)==0:
				break
			t=line.split()
			motif_n=int(t[0])
			if motif_n not in matseqs:
				matseqs[motif_n]=[]
			matseqs[motif_n].append(line)
			if motif_n>maxMotifN:
				maxMotifN=motif_n
	
	with open(match_file,'w+') as f:
		for i in range(1,maxMotifN+1):
			if i in matseqs:
				f.write('-----------------------------------------------------\n')
				f.write('Motif {0} : {1} occurrences\n'.format(i,len(matseqs[i])))
				f.write('-----------------------------------------------------\n')
				f.write(title)
				for seq in matseqs[i]:
					f.write(seq)
			else:
				f.write('-----------------------------------------------------\n')
				f.write('Motif {0} : {1} occurrences\n'.format(i,0))
				f.write('-----------------------------------------------------\n')
			f.write('\n\n\n')


	command=['python','rank_motifs.py']
	command+=[pwm_file,match_file]
	
	print 'updating motifs based on occurrences'
	print ' '.join(command)
	child=subprocess.Popen(command)
	returncode=child.wait()
	if returncode==None or returncode<0:
		print 'updating runs into error'
		sys.exit(-1)

def runCalcEvalue(args):
	'''
	re-calculate evalue of motifs
	'''
	print '---------------------------'
	pwm_file=os.path.join(args.output_dir,'pwms.txt')
	new_pwm_file=os.path.join(args.output_dir,'pwms_with_new_evalue.txt')

	command=['./re_calc_evalue']
	command+=[args.dataset]
	command+=[pwm_file]
	command+=[os.path.join(args.output_dir,'.fimo')]
	command+=[new_pwm_file]


	print 're-calculating evalues for each motif: '
	print ' '.join(command)
	child=subprocess.Popen(command)
	returncode=child.wait()
	if returncode==None or returncode<0:
		print 're_calc_evalue runs into error'
		sys.exit(-1)

def rmTempFiles(args):
	'''
	remove temporary files
	'''
	print '---------------------------'
	print 'removing temporary files'
	tDir=os.path.join(args.output_dir,'.partitions')
	if os.path.isdir(tDir):
		shutil.rmtree(tDir)

	tDir=os.path.join(args.output_dir,'.meme')
	if os.path.isdir(tDir):
		shutil.rmtree(tDir)

if __name__=='__main__':

        print '-------------------------------------------------------'
        print 'For internal research purpose only.'
        print 'Redistribution and commercial usage are not permitted.'
        print 'For other interests, contact the authors.'
        print '-------------------------------------------------------'

	args=ARGS()
	parser = argparse.ArgumentParser(description='The pipeline of ABP+MEME.')
	setParser(parser)
	parser.parse_args(parseConfig(),namespace=args)
	parser.parse_args(namespace=args)

	genBackground(args)
	#examineFile(args)
	if args.npar is None:
		runABPwithoutParN(args)
	else:
		runABP(args)
	runSampling(args)
	runMEME(args)
	runMerge(args)

	if args.occ:
		runFimo(args)
	if args.re:
		if not args.occ:
			runFimo(args)
		runCalcEvalue(args)
	if not args.text:
		runLogogen(args)
	if not args.verbose:
		rmTempFiles(args)


