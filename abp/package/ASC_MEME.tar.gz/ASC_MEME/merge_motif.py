#
#11/20/2014 2:04:45 PM
#Author: Honglei Liu <liuhonglei@gmail.com>
#
#Description: merge or compare between pwms
#


import sys
import os
# from scipy.stats import *
# import numpy as np
import math
import parse_motif

class Merge:
    "'using KL-divergence to find similar motifs and merge them together'"
    #bg=[]           # background model
    kl_bound=1      # KL threshold to merge two motifs
    beta=0.00001    # remove zeros
    minL=4      # segement length
    e_thres=0.01  # threshold for e-value
    min_occ=10  # minmum number of occurrences

    def merge(self,par):
        mask=[]
        for i in range(len(par.data)):
            if par.data[i]['nsites']<self.min_occ or par.data[i]['evalue']>self.e_thres:
                mask.append(i) 
        for i in range(len(par.data)):
            if i in mask:
                continue
            for j in range(i+1,len(par.data)):
                if j in mask:
                    continue
                kl,shift=self.compare(par.data[i],par.data[j])

                if kl<self.kl_bound:
                    #print "{0}:{1} p:{2}".format(i+1,j+1,kl)
                    #self.combine(par.data[i],par.data[j],shift)
                    if par.data[i]['evalue']>par.data[j]['evalue']:
                        mask.append(i)
                        break;
                        #par.data[i],par.data[j]=par.data[j],par.data[i]
                    else:
                        mask.append(j)
                        continue
        mask.sort()
        mask.reverse()
        for i in mask:
            par.data.pop(i)

    # def calc_pvalue(self,par):
    #     #print self.bg
    #     for m in par.data:
    #         t_bg=[]
    #         for i in range(m['w']):
    #             t_bg.append([x*m['nsites']+5 for x in self.bg])
    #         p_value,shift=self.compare_motif(m['pwm_f'],t_bg)
    #         m['evalue']=p_value

    

    # def combine(self,m1,m2,shift):
    #     weight=float(m2['nsites']/(m1['nsites']+m2['nsites']))
    #     new_pwp=[]
    #     new_pwf=[]

    #     l_1=max(0,shift)
    #     l_2=max(0,0-shift)
    #     lag=m2['w']-m1['w']
    #     r_1=min(m1['w'],m1['w']+min(0,lag+shift))
    #     for t in range(r_1-l_1):
    #         temp_p=[]
    #         temp_f=[]
    #         for k in range(m1['alength']):
    #             temp_p.append((1-weight)*m1['pwm_p'][l_1+t][k]+weight*m2['pwm_p'][l_2+t][k])
    #             temp_f.append(temp_p[-1]*(m1['nsites']+m2['nsites'])+5)
    #         new_pwp.append(temp_p)
    #         new_pwf.append(temp_f)

    #     m1['pwm_p']=new_pwp
    #     m1['pwm_f']=new_pwf
    #     m1['nsites']=m1['nsites']+m2['nsites']
    #     m1['w']=r_1-l_1
    #     m1['evalue']=min(m1['evalue'],m2['evalue'])

    # def compare_motif(self,m1,m2):

    #     w=len(m1)
    #     p_value=0.0
    #     shift=0

    #     for i in range(0-(w-self.minL),w-self.minL+1):     #at least have 6 overlaps
    #         t_p=0
    #         l_1=max(0,i)
    #         r_1=min(w,w+min(0,i))
    #         l_2=max(0,0-i)
    #         r_2=min(w,w-max(0,i))

    #         for j in range(r_1-l_1):
    #             t_p+=chi2_contingency(np.array([m1[l_1+j],m2[l_2+j]]))[1]
    #         t_p=t_p/(r_1-l_1)
    #         if t_p>p_value:
    #             p_value=t_p
    #             shift=i

    #     return p_value,shift


    # def compare(self,m1,m2):
    #     '''m2 shifts, using chi-square test to compare'''

    #     #if(x1['nsites']>x2['nsites']):
    #     #    m1,m2=x1,x2
    #     #else:
    #     #    m1,m2=x2,x1
            
    #     if m1['alength']!=m2['alength']:
    #         print "Different Alphabet set!"
    #         return
        
    #     pwm1=m1['pwm_f']
    #     pwm2=m2['pwm_f']
    #     lag=m2['w']-m1['w']
    #     p_value=0.0
    #     shift=0

    #     for i in range(0-(m2['w']-6),m1['w']-6+1):     #at least have 6 overlaps
    #         t_p=0
    #         l_1=max(0,i)
    #         r_1=min(m1['w'],m1['w']+min(0,lag+i))
    #         l_2=max(0,0-i)
    #         r_2=min(m2['w'],m2['w']-max(0,lag+i))

    #         for j in range(r_1-l_1):
    #             t_p+=chi2_contingency(np.array([pwm1[l_1+j],pwm2[l_2+j]]))[1]
    #         t_p=t_p/(r_1-l_1)
    #         if t_p>p_value:
    #             p_value=t_p
    #             shift=i

    #     return p_value,shift
   

    def compare(self,m1,m2):
        '''m2 shifts, using KL-divergence to compare'''

        #if(x1['nsites']>x2['nsites']):
        #    m1,m2=x1,x2
        #else:
        #    m1,m2=x2,x1
            
        if m1['alength']!=m2['alength']:
            print "pwms have different Alphabet set!"
            return
        
        pwm1=m1['pwm_p']
        pwm2=m2['pwm_p']
        lag=m2['w']-m1['w']
        p_value=sys.float_info.max
        shift=0

        for i in range(0-(m2['w']-self.minL),m1['w']-self.minL+1):     #at least have 6 overlaps
            t_p=0
            l_1=max(0,i)
            r_1=min(m1['w'],m1['w']+min(0,lag+i))
            l_2=max(0,0-i)
            r_2=min(m2['w'],m2['w']-max(0,lag+i))

            for j in range(r_1-l_1):
                for k in range(m1['alength']):
                    # make sure the probability is not zero
                    tp1=pwm1[l_1+j][k]
                    if tp1==0:
                        tp1+=self.beta
                    tp2=pwm2[l_2+j][k]
                    if tp2==0:
                        tp2+=self.beta
                    # calculate KL-Divergence
                    t_p+=tp1*(math.log(tp1)-math.log(tp2))
            t_p=t_p/(r_1-l_1)
            if t_p<p_value:
                p_value=t_p
                shift=i

        return p_value,shift
            
    # def readbg(self,bg_file):
    #     ''' read background model'''
    #     with open(bg_file) as f:
    #         while True:
    #             line=f.readline()
    #             if(len(line)==0):
    #                 return 
    #             if(line.startswith("Background letter frequencies")):
    #                 line=f.readline()
    #                 t=line.strip().split()
    #                 for i in range(len(t)):
    #                     if i%2!=0:
    #                         self.bg.append(float(t[i]))

    def output(self,par,out_file):
        motif_num=0
        with open(out_file,'a') as f:
            for m in par.data:
                motif_num+=1
                f.write("MOTIF "+str(motif_num)+"\n")
                f.write("letter-probability matrix: alength= "+str(m['alength'])+" w= "+str(m['w'])+" nsites= "+str(m['nsites'])+" E= "+'{0:.2e}'.format(m['evalue'])+"\n")
                for row in m['pwm_p']:
                    f.write("  ".join(map(str,row))+"\n")
                f.write("\n\n\n")


    def compare_with_meme(self,mine_par,meme_par):

        print "mine motifs number: "+str(len(mine_par.data))
        print "meme motifs number: "+str(len(meme_par.data))
        common=0
        for i in range(len(mine_par.data)):
            for j in range(len(meme_par.data)):
                kl,shift=self.compare(mine_par.data[i],meme_par.data[j])
                #print "{0:3}:{1:3}  {2:3}   {3:3}".format(i+1,j+1,kl,shift)
                if(kl<self.kl_bound):
                    common+=1
                    print "{0:3}:{1:3}  {2:3}   {3:3}".format(i+1,j+1,kl,shift)
                    break 
        print "\n"
        print "common number of motifs: {0}".format(common)


if __name__ == '__main__':
    '''
    [1] -merge
        [2] output file name
        [3] KL bound
        [4] e-value bound
        [5] segment length
        [6] minimum number of occurrences
        [7:] meme.txt files
    [1] -compare
        [2] mine pwm file
        [3] meme pwm file
    '''
    if sys.argv[1]=='-merge':
        if len(sys.argv)<8:
            print "too few arguments!"
            sys.exit()

        mer=Merge()
        out_file=sys.argv[2]
        mer.kl_bound=float(sys.argv[3])
        mer.e_thres=float(sys.argv[4])
        mer.minL=int(sys.argv[5])
        mer.min_occ=int(sys.argv[6])
        
        par=parse_motif.Parser(sys.argv[7:])
        
        mer.merge(par)
        #mer.readbg(out_file)
        #mer.calc_pvalue(par)
        mer.output(par,out_file)
        #command="./meme2images -eps "+out_file+" "+image_dir
        #os.system(command)
    elif sys.argv[1]=='-compare':
        mine_file=sys.argv[2]
        meme_file=sys.argv[3]
        mer=Merge()
        par_mine=parse_motif.Parser([mine_file])
        par_meme=parse_motif.Parser([meme_file])
        mer.compare_with_meme(par_mine,par_meme)


    
    #print len(par.data)
        
