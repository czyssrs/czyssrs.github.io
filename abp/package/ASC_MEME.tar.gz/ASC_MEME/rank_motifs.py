#
#1/16/2015 12:12:07 PM
#Author: Honglei Liu <liuhonglei@gmail.com>
#
#Description: update and rank motifs based on their numbers of occurrences
#

import os
import sys
#import re

header=''

def readpwms(infile):
    ''' read and parse pwm file'''
    #pattern=re.compile(r"^letter-probability matrix:\s+(.*)$")
    motifs=[]
    count=0
    start=False
    global header
    with open(infile) as f:
        while True:
            line=f.readline()
            if len(line)==0:
                break
            #if pattern.match(line) is not None:
            if line.startswith('MOTIF'):
                line=f.readline()
                start=True
                motifs.append({})
                sp=line.split()
                motifs[count]['alength']=int(sp[3])
                motifs[count]['w']=int(sp[5])
                motifs[count]['nsites']=int(sp[7])
                motifs[count]['evalue']=float(sp[9])

                motifs[count]['pwm_p']=[]
                motifs[count]['pwm_f']=[]                        
                for i in range(motifs[count]['w']):
                    line=f.readline()
                    temp_p=[]
                    temp_f=[]
                    for lp in line.split():
                        t_p=float(lp)
                        temp_p.append(t_p)
                        temp_f.append(motifs[count]['nsites']*t_p+5)  #at least have freq. 5
                    motifs[count]['pwm_p'].append(temp_p[:])
                    motifs[count]['pwm_f'].append(temp_f[:])
                count+=1
            
            if not start:
                header+=line
    return motifs

def readocc(infile):
    ''' read and parse occurrences file'''

    occs=[]
    with open(infile) as f:
        while True:
            line=f.readline()
            if len(line)==0:
            		break
            if line.startswith('Motif'):
                sp=line.split()
                n=int(sp[1])
                nsites=int(sp[3])
                content=''
                line=f.readline()
                for i in range(nsites+1):
                    line=f.readline()
                    content+=line
                occs.append((nsites,n,content))
    occs.sort(reverse=True)
    return occs

def output(pwmfile,motifs,occfile,occs):
    ''' output data'''

    with open(pwmfile,'w+') as fpwm:
        with open(occfile,'w+') as focc:
            fpwm.write(header)
            motif_num=0
            for occ in occs: 
                m=motifs[occ[1]-1]
                m['nsites']=occ[0]
                motif_num+=1
                fpwm.write("MOTIF "+str(motif_num)+"\n")
                fpwm.write("letter-probability matrix: alength= "+str(m['alength'])+" w= "+str(m['w'])+" nsites= "+str(m['nsites'])+" E= "+'{0:.2e}'.format(m['evalue'])+"\n")
                for row in m['pwm_p']:
                    fpwm.write("  ".join(map(str,row))+"\n")
                fpwm.write('\n\n\n')

                focc.write('-----------------------------------------------------\n')
                focc.write('Motif {0} : {1} occurrences\n'.format(motif_num,occ[0]))
                focc.write('-----------------------------------------------------\n')
                focc.write(occ[2])
                focc.write('\n\n\n')


if __name__ == '__main__':

    pwmfile=sys.argv[1]
    occfile=sys.argv[2]
    motifs=readpwms(pwmfile)
    occs=readocc(occfile)
    output(pwmfile,motifs,occfile,occs)

